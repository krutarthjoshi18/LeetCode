def word_parser(input_lines):
    for line in input_lines:
        words = line.split()



def main():
    input_lines = ["a to the four where supers I be the other four"]
    print(word_parser(input_lines))


main()
